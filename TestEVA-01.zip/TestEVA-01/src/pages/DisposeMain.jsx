import React from 'react'
import ForSellComponent from '../components/ForSellComponent'

function DisposeMain() {
  return (
    <>
      
      
      <div className="container mx-auto p-4">
      <h1 className="text-2xl font-semibold mb-4">การทำจำหน่ายครุภัณฑ์</h1>
      <ForSellComponent />
    </div>



    </>
  )
}

export default DisposeMain