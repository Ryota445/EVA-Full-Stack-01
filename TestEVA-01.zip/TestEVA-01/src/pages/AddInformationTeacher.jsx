import React from 'react'

function AddInformationTeacher() {
  return (
    <div>AddInformationTeacher</div>
  )
}

export default AddInformationTeacher