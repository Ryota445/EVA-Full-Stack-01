import React from 'react'

function ReportCheckInventory() {
  return (
    <div>ReportCheckInventory</div>
  )
}

export default ReportCheckInventory