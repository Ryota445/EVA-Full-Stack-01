import React from 'react';
import SearchMaintenant from '../components/searchMaintenant';

function MaintenanceInventoryMain() {
  return (
    <>
      <SearchMaintenant />
      
    </>
  );
}

export default MaintenanceInventoryMain;