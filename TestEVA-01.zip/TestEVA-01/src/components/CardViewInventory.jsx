import React from 'react'
import ItemCardComponent from './ItemCardComponent'

function CardViewInventory() {
  return (
    <div>
    

    
    <ItemCardComponent/>


    </div>
  )
}

export default CardViewInventory