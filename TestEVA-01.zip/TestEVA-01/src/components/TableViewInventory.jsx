import React from 'react'
import {
    EyeOutlined,
    EditOutlined,
    DeleteOutlined,
    
    
  } from '@ant-design/icons';

function TableViewInventory() {
  return (
    <>

<div className="overflow-x-auto border-2 border-black rounded-md p-2 m-4">
  <table className="table table-zebra">
    {/* head */}
    <thead>
      <tr>
        <th></th>
        <th>หมายครุภัณฑ์</th>
        <th>ขื่อครุภัณฑ์</th>
        <th>การจัดการ</th>
      </tr>
    </thead>
    <tbody>
      {/* row 1 */}
      <tr>
        <th>1</th>
        <td>110112 </td>
        <td>เครื่องวิเคราะห์ด้วยแสง</td>
        <td>
            
        <div className='flex flex-row space-x-4'>
        <EyeOutlined  className='text-xl'/>
        <EditOutlined className='text-xl'/>
        <DeleteOutlined className='text-xl'/>
        </div>


        </td>
      </tr>
      {/* row 2 */}
      <tr>
        <th>2</th>
        <td>120021</td>
        <td>เครื่องทำความเย็น</td>
        <td>


        <div className='flex flex-row space-x-4'>
        <EyeOutlined  className='text-xl'/>
        <EditOutlined className='text-xl'/>
        <DeleteOutlined className='text-xl'/>
        </div>

        </td>
      </tr>
      {/* row 3 */}
      <tr>
        <th>3</th>
        <td>2100112</td>
        <td>ตู้อบแห้งด้วยความเย็น</td>
        <td>

        <div className='flex flex-row space-x-4'>
        <EyeOutlined  className='text-xl'/>
        <EditOutlined className='text-xl'/>
        <DeleteOutlined className='text-xl'/>
        </div>

        </td>
      </tr>
    </tbody>
  </table>
</div>

    </>
  )
}

export default TableViewInventory